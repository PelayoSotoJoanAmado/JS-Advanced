class Persona{
    constructor(nombre, nota){
        this._nombre = nombre;
        this._nota = nota;
    }
    get nombre(){
        return this._nombre;
    }
    set nombre(nombre){
        this._nombre = nombre;
    }
    get nota(){
        return this._nota;
    }
    set nota(nota){
        return this._nota = nota;
    }
    
}