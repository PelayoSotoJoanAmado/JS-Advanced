const personas = [

    new Persona('Juan', '18'),
    new Persona('Karla', '15')
];

let notas = [];

function mostrarPersonas(){
    console.log('Mostrar personas...');
    let texto = '';

    // for(let persona of personas){
    //     console.log(persona);
    //     texto += `<li>${persona.nombre} ${persona.nota}</li>`;

    // }
    personas.forEach((persona) => {
        console.log(persona);
        texto += `<li>${persona.nombre} ${persona.nota}</li>`;
    })

    document.getElementById('personas').innerHTML = texto;
    calcularPromedio();
    calcularMaxyMin();
}

function agregarPersona(){
        const forma = document.forms['forma'];
        const nombre = forma['nombre'];
        const nota = forma['nota'];
        if(nombre.value != '' && nota.value != '' && nota.value >= 0 && nota.value <= 20){
            const persona = new Persona(nombre.value, nota.value);
            console.log(persona);
            personas.push(persona);
            mostrarPersonas();
        }
        else{
            alert("Ingresa una nota válida")
            console.log('No hay información que agregar');
        }
}

function calcularPromedio(){
    notas = personas.map(personas => parseInt(personas.nota)) ;

    let suma = 0;
    for (let nota of notas){
        suma += nota
    }
    let promedio = (suma / notas.length).toFixed(2);
    

    console.log("Notas")
    console.log(notas)

    document.getElementById('res').innerHTML = promedio;
}

function calcularMaxyMin(){
    let max = Math.max(...notas);

    let min = Math.min(...notas);

    document.getElementById('max').innerHTML = max;
    
    // contenedorMax.innerHTML += ` ${max}`;

    // const contenedorMax= document.getElementById('max');
    // contenedorMax.insertAdjacentElement('beforeend', "`<p>${max}</p>`");

    document.getElementById('min').innerHTML= min;
    const contenedorMin = document.getElementById('min');

    // contenedorMin.innerHTML += ` ${min}`;
}


const bot = document.getElementById("test");

bot.addEventListener("click", () => {
    agregarPersona()
}

)


let res = document.getElementById("testeo");

res.innerHTML = "tranquilo".toUpperCase();





