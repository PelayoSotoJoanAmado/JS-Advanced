function generarTablas() {
    let numero = document.getElementById("numero").value;
    let resultado = document.getElementById("resultado");
    resultado.innerHTML = "";
    if (numero === "") {
        resultado.innerHTML = "Ingrese un número";
        return;
    }
    numero = parseInt(numero);
    for (let i = 1; i <= 12; i++) {
        resultado.innerHTML += numero + " x " + i + " = " + (numero * i) + "<br>";
    }
}


document.addEventListener("keydown", (event) => {
    if (event.key == "Enter") {
        generarTabla();
    }
})


const generarTabla = () => {
    let numero = document.getElementById("numero").value;
    let resultado = document.getElementById("resultado");
    resultado.innerHTML = "";
    if (numero === "") {
        resultado.innerHTML = "Ingrese un número";
        return;
    }
    numero = parseInt(numero);
    for (let i = 1; i <= 12; i++) {
        resultado.innerHTML += numero + " x " + i + " = " + (numero * i) + "<br>";
    }
}
























































