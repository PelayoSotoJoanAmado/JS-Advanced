function procesar() {
    try {
        let nombre = document.getElementById("nombre").value;
        let edad = document.getElementById("edad").value;
        let nota1 = document.getElementById("nota1").value;
        let nota2 = document.getElementById("nota2").value;
        let nota3 = document.getElementById("nota3").value;
        let nota4 = document.getElementById("nota4").value;


        if (nombre === "" || edad === "" || nota1 === "" 
            || nota2 === "" || nota3 === "" || nota4 === "") {
            alert("Complete los campos");
            return;
        }
        edad = parseInt(edad);

        let mensajeEdad = "";
        if (edad >= 18) {
            mensajeEdad = nombre + " es mayor de edad";
        } else {
            mensajeEdad = nombre + " es menor de edad";
        }


        nota1 = parseInt(nota1);
        nota2 = parseInt(nota2);
        nota3 = parseInt(nota3);
        nota4 = parseInt(nota4);


        let mensajePromedio = "";
        let min = Math.min(nota1, nota2, nota3, nota4);
        let suma = (nota1 + nota2 + nota3 + nota4) - min;
        let promedio = suma / 3;

        if (promedio > 20) {
            mensajePromedio = "El promedio esta fuera de rango. Valor Máximo = 20"
        }
        else if (promedio >= 11.6){
            mensajePromedio = "El alumno " + nombre + " ha aprobado con un promedio de "+ promedio;

        } else {
            mensajePromedio = "El alumno " + nombre + " no ha aprobado con un promedio de "+promedio;
        }
        

        for (let i = 0; i < 1; i++) {
            console.log("Procesando...");
        }



        document.getElementById("resultadoEdad").innerText = mensajeEdad;
        document.getElementById("resultadoNotas").innerText = mensajePromedio;
    } catch (error) {
        console.error("Error:", error);
        alert("Ocurrió un error");
    }
}


