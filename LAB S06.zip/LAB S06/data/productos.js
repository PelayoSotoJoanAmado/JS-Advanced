const productos = [
    {
        id: 1,
        nombre: "Laptop Lenovo",
        precio: 2500,
        stock: 10
    },
    {
        id: 2,
        nombre: "Mouse Logitech",
        precio: 80,
        stock: 25
    },
    {
        id: 3,
        nombre: "Teclado mecánico",
        precio: 180,
        stock: 15
    }
];

export default productos;