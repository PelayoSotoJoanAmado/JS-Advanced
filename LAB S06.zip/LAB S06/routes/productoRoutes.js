import { Router } from 'express'
import { 
    listarProductos, 
    actualizarProducto, 
    buscarProductoPorId,
    eliminarProducto,
    listarProductosDisponibles,
    registrarProducto 
} from '../controllers/productoController.js'



const router = Router();

router.get("/", listarProductos);
router.get("/disponibles", listarProductosDisponibles);
router.get("/:id", buscarProductoPorId);
router.post("/", registrarProducto);
router.put("/:id", actualizarProducto);
router.delete("/:id", eliminarProducto);



export default router;