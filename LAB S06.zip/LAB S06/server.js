import express from 'express';
import productRouter from "./routes/productoRoutes.js"
import cors from 'cors'

const app = express();
const PORT = 5000 | 5002;
// const PORT = process.env.PORT | 5002;

const ACCEPTED_ORIGINS = [
    'http://127.0.0.1:3000', 
    'http://127.0.0.1:3002',
    // 'http://localhost:3000'
];

const corsOptions = {
    origin: (origin, callback) => {
        if (ACCEPTED_ORIGINS.includes(origin) || !origin) {
            callback(null, true);
        } else {
            callback(new Error('Not allowed by CORS'));
        }
    },
    optionsSuccessStatus: 200,
    credentials: true // Permite que el navegador envíe y reciba cookies
}

app.use(cors(corsOptions));

app.use(express.json());

app.get("/", (req, res) => {
    res.send("Hola mundo");
})

app.get("/health", (req, res) => {
res.status(200).json({
        status: "OK",
        uptime: process.uptime()
    })
})

app.listen(PORT, () => {
    console.log(`Servidor iniciado en el puerto ${PORT}`);
})


app.use("/api/productos", productRouter);



